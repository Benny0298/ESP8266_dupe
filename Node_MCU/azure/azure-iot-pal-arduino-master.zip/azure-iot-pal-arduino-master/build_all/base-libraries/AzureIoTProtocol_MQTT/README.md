#### Azure IoT Protocol MQTT Library source files

This is the location of the Arduino-specific source files for the
[AzureIoTProtocol_MQTT Arduino published library](https://github.com/Azure/azure-iot-arduino-protocol-mqtt). 

Complete information for contributing to the Azure IoT Arduino libraries
can be found [here](https://github.com/Azure/azure-iot-pal-arduino).
