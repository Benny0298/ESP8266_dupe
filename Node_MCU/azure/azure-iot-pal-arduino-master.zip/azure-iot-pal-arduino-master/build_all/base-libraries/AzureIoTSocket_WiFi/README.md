#### Azure IoT Utility

This is the location of the Arduino-specific source files for the
[AzureIoTUtility Wi-Fi adapter Arduino published library](https://github.com/Azure/azure-iot-arduino-socket-wifi). 

Complete information for contributing to the Azure IoT Arduino libraries
can be found [here](https://github.com/Azure/azure-iot-pal-arduino).