#### Azure IoT Utility

This is the location of the Arduino-specific source files for the
[AzureIoTUtility Arduino published library](https://github.com/Azure/azure-iot-arduino-utility). 

Complete information for contributing to the Azure IoT Arduino libraries
can be found [here](https://github.com/Azure/azure-iot-pal-arduino).