output_path = ''

cmds = {
    "help":         {'short': 'h', 'text': "print help text"},
    "output":       {'short': 'o', 'text': "arg required: Sets the path used to save output folders and libraries."},
    }
