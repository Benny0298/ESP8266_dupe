#pragma once
#ifndef _myTimer_h
#define _myTimer_h

/****************************************
* * * * * * I N C L U D E S * * * * * * * 
****************************************/
#include <Arduino.h>
#include <Ticker.h>

/****************************************
* * * * * * * D E F I N E S * * * * * * * 
****************************************/
// Modbus RTU
#define TIMER1_TICKS_HALF_S 156250
#define TIMER1_TICKS_ONE_S  312500
#define TIMER1_TICKS_TWO_S  625000

/****************************************
* * * * * P R O T O T Y P E S * * * * * * 
****************************************/
namespace myTimer
{
  void ICACHE_RAM_ATTR onTime();
} // end of namespace
/****************************************
* * * * * * * * * E O F * * * * * * * * * 
****************************************/
#endif
